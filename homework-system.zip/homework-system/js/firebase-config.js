// ============================================================
//  FIREBASE AYARLARI
//  1. https://console.firebase.google.com adresine git
//  2. Yeni proje oluştur (veya mevcut projeyi seç)
//  3. "Web uygulaması ekle" (</> ikonu)
//  4. Aşağıdaki değerleri kendi projeninkilerle değiştir
//  5. Authentication > Sign-in method > Email/Password'ü aç
//  6. Authentication > Users > Add user ile bir admin hesabı oluştur
//  7. Firestore Database > Create database (test mode ile başla)
//  8. Storage > Get started (test mode ile başla)
// ============================================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
export const storage = getStorage(app);
export const auth = getAuth(app);
