import { db } from "./firebase-config.js";
import {
  collection,
  query,
  orderBy,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

// DOM
const taskListEl = document.getElementById("task-list");
const emptyStateEl = document.getElementById("empty-state");
const viewTitleEl = document.getElementById("view-title");
const menuBtn = document.getElementById("menu-btn");
const sideMenu = document.getElementById("side-menu");
const sideMenuOverlay = document.getElementById("side-menu-overlay");
const closeMenuBtn = document.getElementById("close-menu");
const subjectListEl = document.getElementById("subject-list");
const detailModal = document.getElementById("detail-modal");
const closeDetailBtn = document.getElementById("close-detail");
const detailTitleEl = document.getElementById("detail-title");
const detailBodyEl = document.getElementById("detail-body");

let allTasks = [];
let currentSubject = "all";

// Subject icons map
const subjectIcons = {
  "Matematik": "📐",
  "Türkçe": "📖",
  "Fen Bilimleri": "🔬",
  "Sosyal Bilgiler": "🌍",
  "İngilizce": "🇬🇧",
  "Din Kültürü": "🕊️",
  "Beden Eğitimi": "⚽",
  "Müzik": "🎵",
  "Görsel Sanatlar": "🎨",
  "Teknoloji ve Tasarım": "🛠️",
  "Diğer": "📌"
};

function getSubjectIcon(subject) {
  return subjectIcons[subject] || "📌";
}

function formatDate(timestamp) {
  if (!timestamp) return "";
  const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const due = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const diffDays = Math.round((due - today) / (1000 * 60 * 60 * 24));

  const options = { day: "numeric", month: "short" };
  const formatted = date.toLocaleDateString("tr-TR", options);

  if (diffDays < 0) return { text: `${formatted} (geçti)`, class: "urgent" };
  if (diffDays === 0) return { text: "Bugün", class: "urgent" };
  if (diffDays === 1) return { text: "Yarın", class: "soon" };
  if (diffDays <= 3) return { text: `${formatted} (${diffDays} gün)`, class: "soon" };
  return { text: formatted, class: "" };
}

function getFileIcon(fileType) {
  if (fileType === "application/pdf" || (fileType && fileType.includes("pdf"))) {
    return { icon: "📄", class: "pdf" };
  }
  return { icon: "🖼️", class: "image" };
}

function renderTasks() {
  let filtered = allTasks;

  if (currentSubject !== "all") {
    filtered = allTasks.filter(t => t.subject === currentSubject);
  }

  // Sort by due date ascending (nearest first)
  filtered = [...filtered].sort((a, b) => {
    const da = a.dueDate?.toMillis?.() || 0;
    const db = b.dueDate?.toMillis?.() || 0;
    return da - db;
  });

  taskListEl.innerHTML = "";

  if (filtered.length === 0) {
    emptyStateEl.style.display = "block";
    return;
  }

  emptyStateEl.style.display = "none";

  filtered.forEach((task, index) => {
    const due = formatDate(task.dueDate);
    const fileInfo = getFileIcon(task.fileType);

    const card = document.createElement("article");
    card.className = "task-card";
    card.style.animationDelay = `${index * 0.04}s`;
    card.innerHTML = `
      <div class="task-icon ${fileInfo.class}">${fileInfo.icon}</div>
      <div class="task-content">
        <h3 class="task-title">${escapeHtml(task.title)}</h3>
        <div class="task-meta">
          <span class="task-subject">${escapeHtml(task.subject)}</span>
          <span class="task-due ${due.class}">📅 ${due.text}</span>
        </div>
      </div>
    `;
    card.addEventListener("click", () => openDetail(task));
    taskListEl.appendChild(card);
  });
}

function renderSubjects() {
  // Keep the "Tüm Görevler" button
  const uniqueSubjects = [...new Set(allTasks.map(t => t.subject))].sort();

  // Remove old subject buttons (keep first one)
  const existing = subjectListEl.querySelectorAll(".subject-item:not([data-subject='all'])");
  existing.forEach(el => el.remove());

  uniqueSubjects.forEach(subject => {
    const btn = document.createElement("button");
    btn.className = "subject-item";
    btn.dataset.subject = subject;
    btn.innerHTML = `
      <span class="subject-icon">${getSubjectIcon(subject)}</span>
      ${escapeHtml(subject)}
    `;
    if (currentSubject === subject) btn.classList.add("active");
    btn.addEventListener("click", () => selectSubject(subject));
    subjectListEl.appendChild(btn);
  });

  // Update active state on "all"
  const allBtn = subjectListEl.querySelector("[data-subject='all']");
  if (allBtn) {
    allBtn.classList.toggle("active", currentSubject === "all");
  }
}

function selectSubject(subject) {
  currentSubject = subject;
  viewTitleEl.textContent = subject === "all" ? "Yaklaşan Ödevler" : subject;
  renderTasks();
  renderSubjects();
  closeMenu();
}

function openDetail(task) {
  const due = formatDate(task.dueDate);
  const isPdf = task.fileType === "application/pdf" || (task.fileName && task.fileName.toLowerCase().endsWith(".pdf"));

  detailTitleEl.textContent = task.title;
  detailBodyEl.innerHTML = `
    <div class="detail-row">
      <div class="detail-label">Ders</div>
      <div class="detail-value">${escapeHtml(task.subject)}</div>
    </div>
    <div class="detail-row">
      <div class="detail-label">Bitiş Tarihi</div>
      <div class="detail-value ${due.class}">${due.text}</div>
    </div>
    <div class="detail-row">
      <div class="detail-label">Dosya</div>
      <div class="detail-preview">
        ${isPdf
          ? `<a class="pdf-link" href="${task.fileUrl}" target="_blank" rel="noopener">
               <span>📄</span>
               PDF'i Aç
             </a>`
          : `<img src="${task.fileUrl}" alt="${escapeHtml(task.title)}" loading="lazy">`
        }
      </div>
    </div>
    <a class="download-btn" href="${task.fileUrl}" target="_blank" download="${escapeHtml(task.fileName || 'dosya')}">
      ⬇️ İndir
    </a>
  `;
  detailModal.classList.add("open");
}

function closeDetail() {
  detailModal.classList.remove("open");
}

function openMenu() {
  sideMenu.classList.add("open");
  sideMenuOverlay.classList.add("open");
}

function closeMenu() {
  sideMenu.classList.remove("open");
  sideMenuOverlay.classList.remove("open");
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Event listeners
menuBtn.addEventListener("click", openMenu);
closeMenuBtn.addEventListener("click", closeMenu);
sideMenuOverlay.addEventListener("click", closeMenu);
closeDetailBtn.addEventListener("click", closeDetail);
detailModal.addEventListener("click", (e) => {
  if (e.target === detailModal) closeDetail();
});

// "Tüm Görevler" button
const allBtn = subjectListEl.querySelector("[data-subject='all']");
if (allBtn) {
  allBtn.addEventListener("click", () => selectSubject("all"));
}

// Real-time listener
const q = query(collection(db, "tasks"), orderBy("dueDate", "asc"));

onSnapshot(q, (snapshot) => {
  allTasks = snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  }));
  renderSubjects();
  renderTasks();
}, (error) => {
  console.error("Firestore hatası:", error);
  emptyStateEl.style.display = "block";
  emptyStateEl.querySelector("p").textContent = "Bağlantı hatası";
  emptyStateEl.querySelector("span").textContent = "Firebase ayarlarını kontrol et";
});
