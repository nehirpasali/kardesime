import { db, storage, auth } from "./firebase-config.js";
import {
  collection,
  addDoc,
  deleteDoc,
  doc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
  Timestamp
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import {
  ref,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";
import {
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";

// DOM
const addBtn = document.getElementById("add-btn");
const taskModal = document.getElementById("task-modal");
const closeModalBtn = document.getElementById("close-modal");
const cancelBtn = document.getElementById("cancel-btn");
const taskForm = document.getElementById("task-form");
const taskTitleInput = document.getElementById("task-title");
const taskSubjectSelect = document.getElementById("task-subject");
const customSubjectGroup = document.getElementById("custom-subject-group");
const customSubjectInput = document.getElementById("custom-subject");
const taskDueInput = document.getElementById("task-due");
const taskFileInput = document.getElementById("task-file");
const fileUploadArea = document.getElementById("file-upload-area");
const filePlaceholder = document.getElementById("file-placeholder");
const fileSelected = document.getElementById("file-selected");
const fileNameEl = document.getElementById("file-name");
const removeFileBtn = document.getElementById("remove-file");
const submitBtn = document.getElementById("submit-btn");
const loadingOverlay = document.getElementById("loading-overlay");
const adminTaskList = document.getElementById("admin-task-list");
const adminEmptyState = document.getElementById("admin-empty-state");

let selectedFile = null;
let allTasks = [];

// Simple auth gate (email/password via Firebase Auth)
function showLogin() {
  const email = prompt("Yönetici e-posta adresi:");
  if (!email) {
    window.location.href = "index.html";
    return;
  }
  const password = prompt("Şifre:");
  if (!password) {
    window.location.href = "index.html";
    return;
  }

  signInWithEmailAndPassword(auth, email, password)
    .then(() => {
      // success - onAuthStateChanged will handle
    })
    .catch((err) => {
      alert("Giriş başarısız: " + err.message);
      window.location.href = "index.html";
    });
}

onAuthStateChanged(auth, (user) => {
  if (!user) {
    showLogin();
  } else {
    initAdmin();
  }
});

function initAdmin() {
  // Set min date to today
  const today = new Date().toISOString().split("T")[0];
  taskDueInput.min = today;

  // Listen for tasks
  const q = query(collection(db, "tasks"), orderBy("dueDate", "asc"));
  onSnapshot(q, (snapshot) => {
    allTasks = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
    renderAdminTasks();
  });
}

// Subject select change
taskSubjectSelect.addEventListener("change", () => {
  if (taskSubjectSelect.value === "Diğer") {
    customSubjectGroup.style.display = "block";
    customSubjectInput.required = true;
  } else {
    customSubjectGroup.style.display = "none";
    customSubjectInput.required = false;
    customSubjectInput.value = "";
  }
});

// File handling
taskFileInput.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (file) handleFileSelect(file);
});

fileUploadArea.addEventListener("dragover", (e) => {
  e.preventDefault();
  fileUploadArea.classList.add("dragover");
});

fileUploadArea.addEventListener("dragleave", () => {
  fileUploadArea.classList.remove("dragover");
});

fileUploadArea.addEventListener("drop", (e) => {
  e.preventDefault();
  fileUploadArea.classList.remove("dragover");
  const file = e.dataTransfer.files[0];
  if (file) {
    const valid = ["image/jpeg", "image/png", "image/jpg", "application/pdf"];
    if (!valid.includes(file.type) && !file.name.match(/\.(jpg|jpeg|png|pdf)$/i)) {
      alert("Sadece JPG, PNG veya PDF yükleyebilirsin.");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      alert("Dosya 10 MB'dan büyük olamaz.");
      return;
    }
    taskFileInput.files = e.dataTransfer.files;
    handleFileSelect(file);
  }
});

function handleFileSelect(file) {
  selectedFile = file;
  fileNameEl.textContent = file.name;
  filePlaceholder.style.display = "none";
  fileSelected.style.display = "flex";
}

removeFileBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  selectedFile = null;
  taskFileInput.value = "";
  filePlaceholder.style.display = "flex";
  fileSelected.style.display = "none";
});

// Modal controls
function openModal() {
  taskForm.reset();
  selectedFile = null;
  filePlaceholder.style.display = "flex";
  fileSelected.style.display = "none";
  customSubjectGroup.style.display = "none";
  customSubjectInput.required = false;
  taskModal.classList.add("open");
}

function closeModal() {
  taskModal.classList.remove("open");
}

addBtn.addEventListener("click", openModal);
closeModalBtn.addEventListener("click", closeModal);
cancelBtn.addEventListener("click", closeModal);
taskModal.addEventListener("click", (e) => {
  if (e.target === taskModal) closeModal();
});

// Submit
taskForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  if (!selectedFile) {
    alert("Lütfen bir dosya seç.");
    return;
  }

  let subject = taskSubjectSelect.value;
  if (subject === "Diğer") {
    subject = customSubjectInput.value.trim();
    if (!subject) {
      alert("Ders adını yaz.");
      return;
    }
  }

  const title = taskTitleInput.value.trim();
  const dueStr = taskDueInput.value;

  if (!title || !dueStr) {
    alert("Tüm alanları doldur.");
    return;
  }

  // Parse date at local midnight
  const [year, month, day] = dueStr.split("-").map(Number);
  const dueDate = Timestamp.fromDate(new Date(year, month - 1, day, 23, 59, 59));

  submitBtn.disabled = true;
  loadingOverlay.style.display = "flex";

  try {
    // Upload file
    const ext = selectedFile.name.split(".").pop();
    const storagePath = `tasks/${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;
    const storageRef = ref(storage, storagePath);

    await uploadBytesResumable(storageRef, selectedFile);
    const fileUrl = await getDownloadURL(storageRef);

    // Save to Firestore
    await addDoc(collection(db, "tasks"), {
      title,
      subject,
      dueDate,
      fileUrl,
      fileName: selectedFile.name,
      fileType: selectedFile.type,
      storagePath,
      createdAt: serverTimestamp()
    });

    closeModal();
  } catch (err) {
    console.error(err);
    alert("Hata oluştu: " + err.message);
  } finally {
    submitBtn.disabled = false;
    loadingOverlay.style.display = "none";
  }
});

// Render admin list
function renderAdminTasks() {
  adminTaskList.innerHTML = "";

  if (allTasks.length === 0) {
    adminEmptyState.style.display = "block";
    return;
  }

  adminEmptyState.style.display = "none";

  allTasks.forEach((task, index) => {
    const due = formatDate(task.dueDate);
    const isPdf = task.fileType?.includes("pdf") || task.fileName?.toLowerCase().endsWith(".pdf");

    const card = document.createElement("article");
    card.className = "task-card admin-card";
    card.style.animationDelay = `${index * 0.03}s`;
    card.innerHTML = `
      <div class="task-icon ${isPdf ? "pdf" : "image"}">${isPdf ? "📄" : "🖼️"}</div>
      <div class="task-content">
        <h3 class="task-title">${escapeHtml(task.title)}</h3>
        <div class="task-meta">
          <span class="task-subject">${escapeHtml(task.subject)}</span>
          <span class="task-due ${due.class}">📅 ${due.text}</span>
        </div>
      </div>
      <div class="task-actions">
        <button class="icon-btn danger" data-id="${task.id}" data-path="${task.storagePath || ""}" title="Sil">🗑️</button>
      </div>
    `;

    // Delete button
    card.querySelector(".icon-btn.danger").addEventListener("click", async (e) => {
      e.stopPropagation();
      if (!confirm(`"${task.title}" silinsin mi?`)) return;

      loadingOverlay.style.display = "flex";
      try {
        // Delete storage file if path exists
        if (task.storagePath) {
          try {
            await deleteObject(ref(storage, task.storagePath));
          } catch (err) {
            console.warn("Storage silinemedi:", err);
          }
        }
        await deleteDoc(doc(db, "tasks", task.id));
      } catch (err) {
        alert("Silme hatası: " + err.message);
      } finally {
        loadingOverlay.style.display = "none";
      }
    });

    adminTaskList.appendChild(card);
  });
}

function formatDate(timestamp) {
  if (!timestamp) return { text: "", class: "" };
  const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const due = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const diffDays = Math.round((due - today) / (1000 * 60 * 60 * 24));

  const options = { day: "numeric", month: "short" };
  const formatted = date.toLocaleDateString("tr-TR", options);

  if (diffDays < 0) return { text: `${formatted} (geçti)`, class: "urgent" };
  if (diffDays === 0) return { text: "Bugün", class: "urgent" };
  if (diffDays === 1) return { text: "Yarın", class: "soon" };
  if (diffDays <= 3) return { text: `${formatted} (${diffDays} gün)`, class: "soon" };
  return { text: formatted, class: "" };
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
