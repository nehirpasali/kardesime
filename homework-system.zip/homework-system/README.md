# Kardeş Görev Yöneticisi

Mobil uyumlu, sade ve göz yormayan ödev / görev takip sistemi.

## Özellikler

### Öğrenci Görünümü (`index.html`)
- Yaklaşan görevler listesi (bitiş tarihine göre sıralı – en yakın önce)
- Sağ üstteki **üç çizgi** menüden derslere göre filtreleme
- Göreve tıklayınca detay + dosya önizleme / indirme
- JPG, PNG ve PDF destekli

### Yönetici Paneli (`admin.html`)
- Firebase Authentication ile giriş
- **+** butonu ile yeni görev ekleme
- Pop-up form: Başlık, Ders seçimi, Bitiş tarihi, Dosya yükleme
- Görev silme
- Dosyalar Firebase Storage’a yüklenir, veriler Firestore’da tutulur

---

## Kurulum (Firebase)

1. [Firebase Console](https://console.firebase.google.com) → Yeni proje oluştur.

2. **Web uygulaması ekle** (`</>` ikonu) → Config değerlerini kopyala.

3. `js/firebase-config.js` dosyasını aç ve şu alanları kendi değerlerinle değiştir:

```js
const firebaseConfig = {
  apiKey: "AIza...",
  authDomain: "proje-id.firebaseapp.com",
  projectId: "proje-id",
  storageBucket: "proje-id.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};
```

4. **Authentication**
   - Sign-in method → **Email/Password**’ü etkinleştir
   - Users → **Add user** → Yönetici e-posta + şifre oluştur

5. **Firestore Database**
   - Create database → **Test mode** ile başla (sonra kuralları sıkılaştırabilirsin)
   - Location seç (örn. `europe-west`)

6. **Storage**
   - Get started → **Test mode** ile başla

### Önerilen Güvenlik Kuralları (sonra güncelle)

**Firestore:**
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /tasks/{taskId} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }
}
```

**Storage:**
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /tasks/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }
}
```

---

## Çalıştırma

Sadece dosyaları bir web sunucusunda açman yeterli (Firebase CDN kullandığı için).

### Hızlı test (lokal):
```bash
# Proje klasöründe
npx serve .
```
veya VS Code Live Server, Netlify Drop, GitHub Pages, Vercel vb. kullan.

- Öğrenci: `index.html`
- Yönetici: `admin.html` → e-posta + şifre isteyecek

---

## Tasarım Notları

- Göz yormayan açık arka plan + yumuşak kartlar
- Minimal renk paleti (ana vurgu: yumuşak mavi)
- Büyük dokunma alanları (mobil odaklı)
- Gereksiz animasyon yok, sadece hafif geçişler
- Ders menüsü sağdan kayarak açılır

İstersen renkleri, ders listesini veya ekstra özellikleri (tamamlandı işaretleme, bildirim vb.) kolayca değiştirebiliriz.
